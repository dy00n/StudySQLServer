SELECT Names AS names
	 , Author AS author
	 , ReleaseDate AS releaseDate
	 , Price AS price
	 FROM bookstbl